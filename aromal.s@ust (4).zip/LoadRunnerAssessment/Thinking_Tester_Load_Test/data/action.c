Action()
{

	/* Contact List Title check */

	/* Add New Contact */

	web_reg_find("Text=Add Contact", 
		LAST);

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

	lr_think_time(48);

	web_url("addContact", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	/* Add Contact Page Title Check */

	/* Adding Contact */

	web_custom_request("reports", 
		"URL=https://nel.heroku.com/reports?ts=1708754651&sid=af571f24-03ee-46d1-9f90-ab9030c2c74c&s=q3Oh0Nf5oc%2FCQSUdK5r6tamG3uegYvVKDTwkjS5lLyQ%3D", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("reports_2", 
		"URL=https://nel.heroku.com/reports?ts=1708754651&sid=af571f24-03ee-46d1-9f90-ab9030c2c74c&s=q3Oh0Nf5oc%2FCQSUdK5r6tamG3uegYvVKDTwkjS5lLyQ%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/reports+json", 
		"Body=[{\"age\":1,\"body\":{\"elapsed_time\":2485,\"method\":\"POST\",\"phase\":\"application\",\"protocol\":\"http/1.1\",\"referrer\":\"https://thinking-tester-contact-list.herokuapp.com/addContact\",\"sampling_fraction\":0.05,\"server_ip\":\"3.229.186.102\",\"status_code\":400,\"type\":\"http.error\"},\"type\":\"network-error\",\"url\":\"https://thinking-tester-contact-list.herokuapp.com/contacts\",\"user_agent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
		"Chrome/121.0.0.0 Safari/537.36\"}]", 
		LAST);

	lr_think_time(18);

	web_custom_request("contacts_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"firstName\":\"aaa\",\"lastName\":\"aaa\",\"birthdate\":\"1999-09-09\",\"email\":\"pppp@gmail.com\",\"phone\":\"123456789\",\"street1\":\"aaa\",\"street2\":\"aaa\",\"city\":\"aaa\",\"stateProvince\":\"aaa\",\"postalCode\":\"1234\",\"country\":\"aaa\"}", 
		LAST);

	web_url("contactList_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("contacts_3", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	return 0;
}
