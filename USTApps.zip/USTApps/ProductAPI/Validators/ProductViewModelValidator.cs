﻿using FluentValidation;
using ProductAPI.Models.ViewModel;

namespace ProductAPI.Validators
{
    public class ProductViewModelValidator :AbstractValidator<ProductViewModel>
    {
        public ProductViewModelValidator() 
        {
            RuleFor(x => x.ProductName)
                .NotEmpty()
                .NotNull()
                .Length(5, 20);
        }
    }
}
