﻿using Microsoft.EntityFrameworkCore;
using ProductAPI.DBContext.Configuration;
using ProductAPI.Models;

namespace ProductAPI.DBContext
{
    //1. create a class which inherits the DBContext.
    //2. Create property of type DbSet<YourModel>.
    //3.call the constructor of DbContext Class with parameters 'DbContextOptions'.
    //4. in program type builder.Services.AddDbContext<ProductDBContext>(options=>options.UseSqlServer(builder.Configuration.GetConnectionString("ProductConnectionString")));
    public class ProductDBContext:DbContext
    {
        public ProductDBContext(DbContextOptions options) : base(options)//Dbcontext is responsible to create SQL related quries. 
        {                                                                 //everything related to the database should be passed here
        }
       

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new ProductConfiguration());
        }
        public DbSet<Product> Products { get; set; }  //all the classes defiened in Models should be defined in the Dbset 
    }
}
