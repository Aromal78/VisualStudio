﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProductAPI.DBContext;
using ProductAPI.Models;
using ProductAPI.Models.ViewModel;
using ProductAPI.Repository;

namespace ProductAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductRepository _productRepository;
        public ProductController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }
        //[HttpGet]
        //public IActionResult Get()
        //{
        //    var products = _productRepository.GetAllProducts();
        //    return Ok(products);
        //}
        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            var products = await _productRepository.GetAllProductsAsync();
            return Ok(products);
        }
        //[Route("getProductById")]
        [HttpGet("{Id}")]
        public async Task<IActionResult> GetProductById(int Id)
        {
            var product = await _productRepository.GetProductByIdAsync(Id);
            return Ok(product);
        }

        [Route("addproduct")]
        [HttpPost]
        public async Task<IActionResult> Add([FromBody] ProductViewModel productViewModel)
        {
            if(ModelState.IsValid) 
            {
                Product product = new Product();
                product.ProductName = productViewModel.ProductName;
                product.ProductDescription = productViewModel.ProductDescription;
                _productRepository.AddProduct(product);
                return Ok(product);
            }
            return BadRequest(ModelState);
        }
        [HttpDelete("{Id}")]
        public async Task<IActionResult> DeleteProductById(int Id)
        {
            var isProductDeleted=await _productRepository.DeleteProductByIdAsync(Id);
            if (isProductDeleted)
            {
                return Ok("deleted");
            }
            return NotFound("Not deleted");
        }
        [HttpDelete]
        public async Task<IActionResult> DeleteAllProducts()
        {
            var check=await _productRepository.DeleteAllProductsAsync();
            if (check)
            {
                return Ok("deleted");
            }
            return NotFound("Not deleted");
        }
    }
}
