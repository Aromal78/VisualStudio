﻿namespace ProductAPI.Models.ViewModel
{
    public class ProductViewModel
    {
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
    }
}
