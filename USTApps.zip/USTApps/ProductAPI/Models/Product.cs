﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProductAPI.Models
{
    public class Product
    {
        //  [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        //[Required]
        //[StringLength(50)]
        public string ProductName { get; set; }
        //[Required]
        //[StringLength(50)]  
        public string ProductDescription { get; set; }
        //[Range(1,5)]
        //[Required]
        //int ProductRating { get; set; }
    }
}
