﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductAPI.DBContext;
using ProductAPI.Models;
using ProductAPI.Models.ViewModel;

namespace ProductAPI.Repository
{
    public class ProductRepository : IProductRepository
    {
        private readonly ProductDBContext _context;
        public ProductRepository(ProductDBContext context)
        {
            _context = context;
        }

        public IEnumerable<Product> GetAllProducts()
        {
            return _context.Products.ToList();
        }
        public async Task<Product> GetProductByIdAsync(int id) 
        {
           Product product=await _context.Products.FindAsync(id);
            return product;

        }
        public async Task<Product> AddProduct(Product product)
        {
           await _context.Products.AddAsync(product);         // when this is run data will be added to the table
            await _context.SaveChangesAsync();
            return product;
        }

        public async Task<IEnumerable<Product>> GetAllProductsAsync()
        {
           return await _context.Products.ToListAsync();//toListAsync will convert to list Asyncronusly
        }

        public async Task<bool> DeleteProductByIdAsync(int id)
        {
            var deleteProduct = await _context.Products.FindAsync(id);
            if(deleteProduct != null)
            {
                _context.Products.Remove(deleteProduct);
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }
        public async Task<bool> DeleteAllProductsAsync()
        {
            var filteredProduct = await _context.Products.ToListAsync();
            if (filteredProduct.Count > 0)
            {
                _context.Products.RemoveRange(filteredProduct);
                await _context.SaveChangesAsync();
                return true;
                //foreach (var product in _context.Products)
                //{
                //    _context.Products.Remove(product);
                //}
                //await _context.SaveChangesAsync();
            }
            return false;
               
        }
    }
}
