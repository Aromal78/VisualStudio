﻿using ProductAPI.Models;

namespace ProductAPI.Repository
{
    public interface IProductRepository
    {
        IEnumerable<Product> GetAllProducts();
        public Task<IEnumerable<Product>> GetAllProductsAsync();
        public Task<Product> AddProduct(Product product);
        public Task<Product> GetProductByIdAsync(int id);
        public  Task<bool> DeleteProductByIdAsync(int id);
        public Task<bool> DeleteAllProductsAsync();
    }
}
