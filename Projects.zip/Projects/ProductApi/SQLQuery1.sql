﻿create database StudentDB
go
use StudentDB
go
Create table Student( 
student_id int primary key identity(1,1),
student_name varchar(20),
marks int,city varchar(20))
go
insert into Student(student_name,marks,city) values('rahul',1000,'pune'),('shyam',4500,'pune'),('priya',90,'agra'),('Rahulll',100,'pune')
select * from Student;
select * from Student where marks between 400 and 6000 and marks !=1000 and marks!=100;
select count(*),city from Student group by city having count(*) >2;
