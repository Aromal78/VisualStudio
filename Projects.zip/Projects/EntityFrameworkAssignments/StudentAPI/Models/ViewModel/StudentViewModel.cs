﻿namespace StudentAPI.Models.ViewModel
{
    public class StudentViewModel
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }

        public int Age { get; set; }

        public int Marks { get; set; }
    }
}
