﻿using StudentAPI.Models;
using StudentAPI.Models.ViewModel;
using System.Collections;

namespace StudentAPI.Repository
{
    public interface IStudentRepository
    {
        public IEnumerable<Student> GetAllStudent();
        public Task<IEnumerable<Student>> GetAllStudentAsync();

        public Task<Student> AddStudent(Student student);

        public Task<bool> DeleteStudentByIdAsync(int Id);

        public Task<bool> UpdateStudentByIdAsync(int id, Student student);
    }
}
