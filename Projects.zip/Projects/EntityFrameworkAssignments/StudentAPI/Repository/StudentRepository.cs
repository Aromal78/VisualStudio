﻿using Microsoft.EntityFrameworkCore;
using StudentAPI.DBContext;
using StudentAPI.Models;
using StudentAPI.Models.ViewModel;

namespace StudentAPI.Repository
{
    public class StudentRepository : IStudentRepository
    {
        private readonly StudentDBContext _dbContext;
        public StudentRepository(StudentDBContext dbContext)
        {
            _dbContext = dbContext;
        }

            public IEnumerable<Student> GetAllStudent()
        {
            return _dbContext.Students.ToList();
        }

        public async Task<IEnumerable<Student>> GetAllStudentAsync()
        {
            return await _dbContext.Students.ToListAsync();
        }
        public async Task<Student> AddStudent(Student student)
        {
            await _dbContext.Students.AddAsync(student);
            await _dbContext.SaveChangesAsync();
            return student;
        }
        public async Task<bool>DeleteStudentByIdAsync(int Id)
        {
            var studentToRemove=await _dbContext.Students.FindAsync(Id);
            if(studentToRemove != null)
            {
                _dbContext.Students.Remove(studentToRemove);
                _dbContext.SaveChanges();
                return true;
            }
            return false;
        }
        public async Task<bool>UpdateStudentByIdAsync(int id,Student student)
        {
            var StudentToUpdate=await _dbContext.Students.FindAsync(id);
            if(StudentToUpdate != null)
            {
                StudentToUpdate.FirstName=student.FirstName;
                StudentToUpdate.LastName=student.LastName;
                StudentToUpdate.Marks=student.Marks;
                StudentToUpdate.Age=student.Age;
               // StudentToUpdate.Id=id;
               //_dbContext.Update(StudentToUpdate);
             //  await _dbContext.AddAsync(StudentToUpdate);
                await _dbContext.SaveChangesAsync();
                return true;
            }
            return false;
        }
    }
}
