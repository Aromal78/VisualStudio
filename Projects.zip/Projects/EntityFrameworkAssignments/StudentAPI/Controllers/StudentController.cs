﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentAPI.Models;
using StudentAPI.Models.ViewModel;
using StudentAPI.Repository;

namespace StudentAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentRepository _studentRepository;
        public StudentController(IStudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }
        //[HttpGet]
        //public IActionResult GetStudents()
        //{
        //    var students = _studentRepository.GetAllStudent();
        //    return Ok(students);
        //}
        [HttpGet]
        public async Task<IActionResult> GetStudents()
        {
            var students = await _studentRepository.GetAllStudentAsync();
            return Ok(students);
        }
        [Route("addstudent")]
        [HttpPost]
        public async Task<IActionResult> Add([FromBody] StudentViewModel studentViewModel)
        {
            Student student = new Student();
            student.FirstName = studentViewModel.FirstName;
            student.LastName = studentViewModel.LastName;
            student.Age = studentViewModel.Age;
            student.Marks = studentViewModel.Marks;
            _studentRepository.AddStudent(student);
            return Ok(student);
        }
        [Route("Delete_Students{Id}")]
        [HttpDelete]
       // [HttpDelete("{Id}")]

        public async Task<IActionResult> DeleteStudentById(int Id)
        {
            var isDeleted=await _studentRepository.DeleteStudentByIdAsync(Id);
            if (isDeleted)
            {
                return Ok("Student Removed");

            }
            return NotFound("Student Not Found");
        }
        [HttpPut("{Id}")]
        public async Task<IActionResult> UpdateStudentById(int Id, StudentViewModel studentViewModel)
        {
            Student student = new Student();
            student.FirstName = studentViewModel.FirstName;
            student.LastName = studentViewModel.LastName;
            student.Age = studentViewModel.Age;
            student.Marks = studentViewModel.Marks;
            var isupdatedStudent=await _studentRepository.UpdateStudentByIdAsync(Id,student);
            if (isupdatedStudent)
            {
                return Ok("Student Updated");

            }
            return NotFound("Student Not Found !!!");
        }
    }
}
