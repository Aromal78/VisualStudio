﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Assessment
{
    internal class ProductMangement
    {
       public static List<Product> products = new List<Product>();
        public bool AddNewProduct(Product product)
        {
            var productToFind = products.Find(x => x.Name == product.Name && x.Manufactured_Year == product.Manufactured_Year);
            if (productToFind != null)
            {
                return false;
            }
            else
            {
                product.Id = products.Count == 0 ? 5000 : products.Max(x => x.Id) + 1;
                products.Add(product);
                return true;
            }
        }


        public List<Product> ViewAllProducts() { return products; }




        public List<Product> Search_products_based_on_price(double price)
        {
            var products_based_on_price = products.FindAll(x => x.Price > price);
            return products_based_on_price;
        }


        public bool RemoveProductById(int id)
        {

            var productToremove = products.Find(x => x.Id == id);
            if (productToremove != null)
            {
                products.Remove(productToremove);
                return true;
            }
            return false;
        }
    }
}

