﻿using System.Buffers.Text;
using System.Xml.Serialization;
using static System.Net.Mime.MediaTypeNames;

namespace Csharp_Assessment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int choice = 1;
            do
            {
                string temp_Choice;


                ProductValidation productValidation = new ProductValidation();
                ProductMangement productMangement = new ProductMangement();
                Console.WriteLine("------------------------------------------------------");
                Console.WriteLine("                    iCare Management                  ");
                Console.WriteLine("------------------------------------------------------");
                Console.WriteLine("1. Add a product");
                Console.WriteLine("2. View all products");
                Console.WriteLine("3. Search products based on price");
                Console.WriteLine("4. Remove a product based on product id");
                Console.WriteLine("5. Exit");

                Console.WriteLine("------------------------------------------------------");
                Console.WriteLine("Enter your Choice :: ");
                Console.WriteLine("------------------------------------------------------");
                temp_Choice = Console.ReadLine();
                try
                {
                    bool check = int.TryParse(temp_Choice, out choice);
                    if (!check) 
                    {
                        productValidation.CheckIfAStringIsEntered();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("------------------------------------------------------");
                    Console.WriteLine(ex.Message);
                    Console.WriteLine("------------------------------------------------------");
                }
                try
                {
                    productValidation.CheckChoice(choice);

                }
                catch(Exception ex ) { Console.WriteLine(ex.Message); }

                switch (choice)
                {
                    case 1:
                        {
                            string temp_Price, temp_Manufactured_Year;
                            int toStorePrice, toStore_Manufactured_Year;
                            Product product = new Product();
                            try
                            {
                                Console.WriteLine("Enter product name :");
                                product.Name = Console.ReadLine();
                                Console.WriteLine("Enter product description :");
                                product.Description = Console.ReadLine();
                                Console.WriteLine("Enter product price :");
                                temp_Price = Console.ReadLine();

                                bool price_Check = int.TryParse(temp_Price, out toStorePrice);
                                if (price_Check)
                                {
                                    product.Price = toStorePrice;
                                }

                                Console.WriteLine("Enter product Manufactured Year :");
                                temp_Manufactured_Year = Console.ReadLine();

                                bool check_Manufactured_Year = int.TryParse(temp_Manufactured_Year, out toStore_Manufactured_Year);
                                if(!check_Manufactured_Year)
                                {
                                    productValidation.CheckIfAStringIsEntered();
                                }
                                else
                                {
                                    product.Manufactured_Year=toStore_Manufactured_Year;
                                }
                                productValidation.ValidateProduct(product);
                                if (productMangement.AddNewProduct(product))
                                {
                                    Console.WriteLine("------------------------------------------------------");
                                    Console.WriteLine("Product Added Sucessfully !!!");
                                    Console.WriteLine("------------------------------------------------------");

                                }
                                else
                                {
                                    Console.WriteLine("------------------------------------------------------");
                                    Console.WriteLine("Product already exists!");
                                    Console.WriteLine("------------------------------------------------------");
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("------------------------------------------------------");
                                Console.WriteLine(ex.Message);
                                Console.WriteLine("------------------------------------------------------");
                            }
                            break;

                        }
                    case 2:
                        {
                            var allProducts = productMangement.ViewAllProducts();
                            if (allProducts.Count > 0)
                            {
                                foreach (var productVeriable in allProducts)
                                {
                                    Console.WriteLine("------------------------------------------------------");
                                    Console.WriteLine("Product ID :: " + productVeriable.Id + " Product Name :: " + productVeriable.Name + " Product Price :: " + productVeriable.Price + " Product Manufactured Year :: " + productVeriable.Manufactured_Year);
                                    Console.WriteLine("------------------------------------------------------");
                                }
                            }
                            else {
                                Console.WriteLine("------------------------------------------------------");
                                Console.WriteLine("there are no prodcts to be displayed"); }
                            Console.WriteLine("------------------------------------------------------");
                            break;
                        }
                    case 3:
                        {
                            
                            double price;
                            Console.WriteLine("Enter the product Price ");
                            string temp_Price = Console.ReadLine();


                            bool price_Check = double.TryParse(temp_Price, out price);
                            try
                            {
                                if(!price_Check)
                                {
                                    productValidation.CheckIfAStringIsEntered();
                                }
                                productValidation.ValidateProductPrice(price);
                            }
                            catch(Exception ex)
                            {
                                Console.WriteLine("------------------------------------------------------");
                                Console.WriteLine(ex.Message);
                                Console.WriteLine("------------------------------------------------------");
                            }
                            var products_based_on_price = productMangement.Search_products_based_on_price(price);
                            if (products_based_on_price.Count > 0)
                            {
                                foreach (var productVeriable in products_based_on_price)
                                {
                                    Console.WriteLine("------------------------------------------------------");
                                    Console.WriteLine("Product ID :: " + productVeriable.Id + " Product Name :: " + productVeriable.Name + " Product Price :: " + productVeriable.Price + " Product Manufactured Year :: " + productVeriable.Manufactured_Year);
                                    Console.WriteLine("------------------------------------------------------");
                                }
                            }
                            else
                            {
                                Console.WriteLine("------------------------------------------------------");
                                Console.WriteLine("there are no more products to display");
                                Console.WriteLine("------------------------------------------------------");
                            }

                        }
                        break;
                    case 4:
                        {
                            string temp_Id;
                            int id;
                            Console.WriteLine("Enter the ID of the Product you want to remove ");
                            temp_Id=Console.ReadLine();
                            bool check_Id = int.TryParse(temp_Id, out id);
                            try
                            {
                                if (!check_Id)
                                {
                                    productValidation.CheckIfAStringIsEntered();
                                }
                                productValidation.ValidateProductId(id);

                            }
                            catch(Exception ex)
                            {
                                Console.WriteLine("------------------------------------------------------");
                                Console.WriteLine(ex.Message);
                                Console.WriteLine("------------------------------------------------------");
                            }
                            if (productMangement.RemoveProductById(id)) {
                                Console.WriteLine("------------------------------------------------------");
                                Console.WriteLine("Product with Id = " +id+" is removed successfully");
                                Console.WriteLine("------------------------------------------------------");
                            }
                            else
                            {
                                Console.WriteLine("------------------------------------------------------");
                                Console.WriteLine(" faild to find a product with id :"+ id);
                                Console.WriteLine("------------------------------------------------------");
                            }
                            break;
                        }
                       

                    default: break;

                }



            } while (choice!= 5);
        }
    }
}