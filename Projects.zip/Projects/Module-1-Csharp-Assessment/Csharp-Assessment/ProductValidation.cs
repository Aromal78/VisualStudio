﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Assessment
{
    internal class ProductValidation
    {
        public void CheckChoice(int choice)
        {
            if (choice<1 || choice >5) 
            {
                throw new ProductExceptionHandler("Enter a choice between 1 & 4 !!!");
            }
        }

        public void CheckIfAStringIsEntered() 
        {
            throw new ProductExceptionHandler("You must enter a number ");
        }
        public void ValidateProduct(Product product)
        {
            if (product.Price < 0)
            {
                throw new ProductExceptionHandler("The Price of a product must be greater than 0");
            }
            if(product.Manufactured_Year < 0)
            {
                throw new ProductExceptionHandler("The Manufactured Year of a product must be greater than 0");
            }
            if(string.IsNullOrEmpty(product.Description))
            {
                throw new ProductExceptionHandler("The product description cannot be null or empty");

            }
            if (string.IsNullOrEmpty(product.Name))
            {
                throw new ProductExceptionHandler("The product name cannot be null or empty");

            }
        }
        public void ValidateProductPrice(double price)
        {
            if (price < 0)
            {
                throw new ProductExceptionHandler("The Price of the product must be greater than 0");
            }
        }
        public void ValidateProductId(int productId)
        {
            if(productId < 5000) 
            {
                throw new ProductExceptionHandler("the product Id must be greater than 5000");
            }
        }
    }
    public class ProductExceptionHandler :Exception
    {
       public ProductExceptionHandler (string message) :base(message) { }
    }
}
