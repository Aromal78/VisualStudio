﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Students.Models;
using Students.StudentServices;

namespace Students.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentService studentService;
        public StudentController(IStudentService _studentService) 
        {
            studentService = _studentService;
        }
        [Route("GetAllStudents")]
        [HttpGet]
        public IActionResult GetAllStudents() 
        { 
            var StudentsList=studentService.GetAllStudents();
            if(StudentsList.Count > 0)
            {
                return Ok(StudentsList);

            }
            return NotFound("No Records Found");
        }
        //[HttpPost]
        //public IActionResult AddStudents([FromBody] StudentViewModel studentViewModel)
        //{
        //    Student student = new Student();
        //   student.Name = studentViewModel.Name;
        //    student.Description = studentViewModel.Description; 
        //    if (studentService.AddStudent(student))
        //    {
        //        return Ok("Student Added Sucessfully");
        //    }
        //     return NotFound("Student Already Exists in the list");
        //}
        [HttpPost]
        public IActionResult AddStudents([FromBody] StudentViewModel studentViewModel)
        {
            if (studentService.AddStudent(studentViewModel))
            {
                return Ok("Student Added Sucessfully");

            }
            return NotFound("Student Added Sucessfully");

        }
        [Route("Update_Student{id}")]
        [HttpPut]
       // [HttpPut("{id}")]
        public IActionResult UpdateStudent([FromBody] StudentViewModel studentVM, int id)
        {
            Student student = new Student();
            student.Id = id;
            student.Name = studentVM.Name;
            student.Description = studentVM.Description;
            if (studentService.UpdateStudent(student, id))
            {
                return Ok(student);
            }
            return NotFound("Student Not Found");
        }
        [HttpDelete("{id}")]
        public IActionResult DeleteStudents(int id)
        {
            if (studentService.DeleteStudentbyId(id))
            {
                return Ok("Student deleted");
            }
            return NotFound("Student Not Found");
        }
        [HttpDelete]
        public IActionResult DeleteAllStudents()
        {
            if (studentService.DeleteAllStudents())
            {
                return Ok("Student deleted");
            }
            return NotFound("There are no more students to remove");
        }
    }
}
