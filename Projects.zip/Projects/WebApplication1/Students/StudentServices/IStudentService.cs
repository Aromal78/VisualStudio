﻿using Students.Models;

namespace Students.StudentServices
{
    public interface IStudentService
    {
        public bool UpdateStudent(Student student,int id);
        public IReadOnlyList<Student> GetAllStudents();

        //public bool AddStudent(Student student);
        public bool AddStudent(StudentViewModel studentViewModel);
        public bool DeleteStudentbyId(int id);

        public bool DeleteAllStudents();

    }
}
