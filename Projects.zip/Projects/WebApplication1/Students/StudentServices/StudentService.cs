﻿using Students.Models;

namespace Students.StudentServices
{
    public class StudentService: IStudentService
    {
        static List<Student> students = new List<Student>();
        
        //public bool AddStudent(Student student)
        //{
        //    var studentCheck=students.Find(x=>x.Name==student.Name);
        //    if (studentCheck==null) 
        //    {
        //        student.Id = students.Count == 0 ? 1 : students.Max(x => x.Id) + 1;
        //        students.Add(student);
        //        return true;
        //    }
        //   return false;    
           
        //}
        public bool AddStudent(StudentViewModel studentViewModel)
        {
            var studentCheck = students.Find(x => x.Name == studentViewModel.Name);
            if (studentCheck == null)
            {
                Student student = new Student();
                student.Name = studentViewModel.Name;
                student.Description = studentViewModel.Description;
                student.Id = students.Count == 0 ? 1 : students.Max(x => x.Id) + 1;
                students.Add(student);
                return true;
            }
            return false;

        }

        public IReadOnlyList<Student> GetAllStudents() 
        {
            return students;
        }
        public bool UpdateStudent(Student student,int id)
        {
          var StudentCheck=students.Find(x=>x.Id ==id); 
            if( StudentCheck != null)
            {
                StudentCheck.Name = student.Name;
                StudentCheck.Description = student.Description;
                return true;
            }
            return false;   
        }
        public bool DeleteStudentbyId(int id) 
        {
            var studentToRemove=students.Find(x=>x.Id == id);
            if( studentToRemove != null )
            {
                students.Remove(studentToRemove);
                return true;
            }
            return false;
        }
        public bool DeleteAllStudents()
        {
            if( students.Count > 0 )
            {
                students.Clear();
                return true;
            }
            return false;
        }
    }
}
