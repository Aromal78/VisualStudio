﻿namespace Students.Models
{
    public class StudentViewModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
