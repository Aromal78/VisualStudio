﻿namespace Sdet_Module1_Training
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int> { -26, 71, 6, -3, -69 };
            int len=list.Count;
            int score = 0;
            for(int i=0; i<len-1; i++)
            {
                int sum = list[i] + list[i+1];
                if (sum % 2 == 0)
                {
                    score = score + 5;
                }
            }
            for(int i=0; i<len-2; i++)
            {
                int sum = list[i] + list[i + 1] + list[i+2];
                int pro = list[i] * list[i + 1] * list[i+2];
                if(sum % 2 != 0 && pro % 2 == 0)
                {
                    score = score + 10;
                }
            }
            Console.WriteLine(score);
        }
    }
}