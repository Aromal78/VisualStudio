﻿namespace LINQ_Demo_Programs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4, 5 };

            // Query to find even numbers
            var evenNumbers = from num in numbers
                              where num % 2 == 0
                              select num;

            // Query to find numbers greater than 3
            var greaterThanThree = numbers.Where(num => num > 3);

            // Query to find the sum of all numbers
            var sum = numbers.Sum();

            // Query to find the average of all numbers
            var average = numbers.Average();

 

            // Query to check if any number is divisible by 5
            var anyDivisibleByFive = numbers.Any(num => num % 5 == 0);

            // Execute the queries and display the results
            Console.WriteLine("Even numbers:");
            foreach (var num in evenNumbers)
            {
                Console.WriteLine(num);
            }

            Console.WriteLine("\nNumbers greater than 3:");
            foreach (var num in greaterThanThree)
            {
                Console.WriteLine(num);
            }

            Console.WriteLine("\nSum of all numbers: " + sum);
            Console.WriteLine("Average of all numbers: " + average);
     
            Console.WriteLine("Is any number divisible by 5? " + anyDivisibleByFive);

            Console.WriteLine("\nPress any key to exit.");
            Console.ReadKey();
        }
    }
}