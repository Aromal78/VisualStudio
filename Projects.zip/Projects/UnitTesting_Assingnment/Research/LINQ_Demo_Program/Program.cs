﻿namespace LINQ_Demo_Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Create an array of tasks
            Task<int>[] tasks = new Task<int>[3];

            // Start three tasks that perform some calculations
            tasks[0] = Task.Run(() => CalculateSum(10));
            tasks[1] = Task.Run(() => CalculateSum(20));
            tasks[2] = Task.Run(() => CalculateSum(30));

            // Wait for all tasks to complete
            Task.WaitAll(tasks);

            // Retrieve and display the results
            for (int i = 0; i < tasks.Length; i++)
            {
                Console.WriteLine($"Task {i + 1} result: {tasks[i].Result}");
            }

            Console.WriteLine("All tasks completed. Press any key to exit.");
            Console.ReadKey();
        }

        static int CalculateSum(int n)
        {
            int sum = 0;
            for (int i = 1; i <= n; i++)
            {
                sum += i;
            }
            return sum;
        }
    }
}