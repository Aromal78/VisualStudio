﻿namespace Var_Vs_Dynamic_Comparison_Demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Example using var
            var varValue = 10;
            var varValue1 = "Aromal";

           
          //  varValue = "Hello"; // Error: Cannot implicitly convert type 'string' to 'int'
          //  var varValue2;

            // Example using dynamic
            dynamic dynamicValue = 10;
            dynamicValue = "Hello"; // No compile-time error
            dynamic dynamicValue2; // it is not nessesary to initalize dynamic veriable          
            dynamic str = "hello";
            int i = str.Length;
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
            
        }
    }
}