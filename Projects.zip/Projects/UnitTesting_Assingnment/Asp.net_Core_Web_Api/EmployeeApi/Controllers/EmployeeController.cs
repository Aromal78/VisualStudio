﻿using EmployeeApi.Model;
using EmployeeApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        IEmployeeService employeeService;
        EmployeeController(IEmployeeService employeeService)
        {
            this.employeeService = employeeService;
        }
        [HttpGet]
        public IActionResult Get()
        {
           var employees= employeeService.GetAllEmployees();
            if (employees.Count() == 0)
            {
                return NotFound("No records fpund");
            }
            return Ok(employees);

        }
        [HttpPost]
        public IActionResult Post([FromBody]Employee employee)
        {
            employeeService.AddEmployee(employee);
           return Ok(employee);


        }
    }
}
