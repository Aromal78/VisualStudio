﻿using EmployeeApi.Model;


namespace EmployeeApi.Services
{
    public class EmployeeService : IEmployeeService
    {
        List<Employee> employeeList=new List<Employee>();   
        public IEnumerable<Employee> AddEmployee(Employee employee)
        {
            employee.Id = employeeList.Count == 0 ? 1 : employeeList.Max(E => E.Id) + 1;
            employeeList.Add(employee);
            return employeeList;
        }
        public IEnumerable<Employee> GetAllEmployees()
        {
            return employeeList;
        }
    }
}
