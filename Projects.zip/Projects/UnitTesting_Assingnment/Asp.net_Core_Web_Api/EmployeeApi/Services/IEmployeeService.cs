﻿using EmployeeApi.Model;

namespace EmployeeApi.Services
{
    public interface IEmployeeService
    {
        public IEnumerable<Employee> AddEmployee(Employee employee);
        public IEnumerable<Employee> GetAllEmployees(); 
    }
}
