﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentApi.Models;
using StudentApi.Services;

namespace StudentApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        static List<Student> students = new List<Student>();
        
        //StudentServices service=new StudentServices();
        
        IStudentService studentService;

        public StudentController(IStudentService studentService)
        {
          this.studentService=  studentService  ;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var student = studentService.GetStudents();
            if (student.Count()==0)
            {
                return NotFound("No records found");
            }
            return Ok(student);
            
        }
        [HttpPost]
        public IActionResult Post([FromBody] Student student)
        {
            var students=studentService.Add(student);
            return Ok(student);
        }
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {

            if (studentService.Dispose(id))
            {
                return Ok("student removed sucessfully");
            }
            return NotFound("student not found");
        }
        [HttpPut("{id}")]
        public IActionResult Update(Student student,int id)
        {
           if(studentService.UpdateStudent(student, id))
            {
                return Ok("Record updated sucessfully !!!");

            }
            else
            {
                return NotFound("record not found !!!");
            }


        }

    }
}
