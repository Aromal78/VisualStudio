﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentApi.Models;
using System.Security.Cryptography.X509Certificates;

namespace StudentApi.Services

{
 
    public class StudentServices : IStudentService
    {
        static List<Student> students = new List<Student>();

        
       
      public  IEnumerable<Student> Add(Student student)
        {
            student.Id = students.Count == 0 ? 1 : students.Max(x => x.Id) + 1;
            students.Add(student);
            return students;

        }
        public  IEnumerable<Student> GetStudents()
        {
            return students;
        }
        public bool Dispose(int id)
        {
            var studentToRemove = students.Find(studentTemp => studentTemp.Id == id);
            if (studentToRemove == null)
            {
                return false;
            }
            students.Remove(studentToRemove);
            return true;
        }
        public bool UpdateStudent(Student student, int id)
        {
            var _student = students.Find(temp => temp.Id == id);
            if (_student != null)
            {
                _student.Id = student.Id;
                _student.Age = student.Age;
                _student.LastName = student.LastName;
                _student.FristName = student.FristName;
                return true;
            }
            return false;
        }

        
        }
        

    }

