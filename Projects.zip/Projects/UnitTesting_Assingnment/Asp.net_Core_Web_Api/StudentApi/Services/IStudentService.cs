﻿using StudentApi.Models;
namespace StudentApi.Services
{
    public interface IStudentService
    {
        public  IEnumerable<Student> Add(Student student);
        public IEnumerable<Student> GetStudents();

        public bool Dispose(int id);

        public bool UpdateStudent(Student student, int id);


    }
}
