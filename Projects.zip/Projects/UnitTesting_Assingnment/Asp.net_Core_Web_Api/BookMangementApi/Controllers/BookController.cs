﻿using BookMangementApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookMangementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        IBookServices bookServices;
        public BookController() 
        {
            
        }
        [HttpGet]
        public IActionResult GetAllBooks()
        {
           var AllBooks= bookServices.Get_All_Books();
            if (AllBooks.Count > 0)
            {
                return Ok(AllBooks);
            }
            return NotFound("there are no Books to display");
        }
    }
}
