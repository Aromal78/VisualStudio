﻿using BookMangementApi.Models;

namespace BookMangementApi.Services
{
    public interface IBookServices
    {
        public IReadOnlyList<Book> Get_All_Books();
    }
}
