﻿using BookMangementApi.Models;

namespace BookMangementApi.Services
{
    public class BookServices : IBookServices
    {
        public List<Book> books = new List<Book>();
        public IReadOnlyList<Book> Get_All_Books() { return books; }

    }
}
