namespace Calculator.Tests.Units
{
    public class CalculatorTests
    {
        [Theory]
        [InlineData(5,5,10)]
        [InlineData(-5,5,0)]
        [InlineData(-15,-5,-20)]
        public void Add_ShouldTakeTwoIntegers_And_ReturnAnInteger(int fristNumber,int secondNumber,int expectedOutput)
        {
            var calcutalors = new Calculators();
            var actualResult=calcutalors.Add(fristNumber, secondNumber);
            Assert.Equal(expectedOutput, actualResult);

        }
        [Theory]
        [InlineData(5,5,0)]
        [InlineData(15,5,10)]
        [InlineData(-5,-5,0)]
        [InlineData(-15,-5,-10)]
        [InlineData(5,10,-5)]

        public void Substract_ShouldTakeTwoIntegers_And_ReturnAnInteger(int fristNumber, int secondNumber, int expectedOutput)
        {
            var calculators=new Calculators();
            var actualResult=calculators.Substract(fristNumber, secondNumber);
            Assert.Equal(expectedOutput, actualResult);

        }
        [Theory]
        [InlineData(5,5,25)]
        [InlineData(50,0,0)]
        [InlineData(-5,5,-25)]
        public void Multiplication_ShouldTakeTwoIntegers_And_ReturnAnInteger(int fristNumber, int secondNumber, int expectedOutput)
        {
            var calculators = new Calculators();
            var actualResult = calculators.Multiplication(fristNumber, secondNumber);
            Assert.Equal(expectedOutput, actualResult);

        }
        [Theory]
        [InlineData(5,5,1)]
        [InlineData(15,5,3)]
        [InlineData(5,0,0,Skip ="skip")]
        public void Division_ShouldTakeTwoIntegers_And_ReturnAnInteger(int fristNumber, int secondNumber, int expectedOutput)
        {
            var calculators = new Calculators();
            var actualResult = calculators.Division(fristNumber, secondNumber);
            Assert.Equal(expectedOutput, actualResult);

        }


    }
}