﻿namespace Calculator
{
    public class Calculators
    {
        public int Add(int fristNumber, int secondNumber)
        {
            return (fristNumber + secondNumber);
        }
        public int Substract(int fristNumber, int secondNumber)
        {
            return (fristNumber - secondNumber);
        }
        public int Multiplication(int fristNumber, int secondNumber)
        {
            return (fristNumber * secondNumber);
        }
        public int Division(int fristNumber, int secondNumber)
        {
            return (fristNumber / secondNumber);
        }

    }
}