﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_2_Book_Management_System
{
    internal class BookManagementSystem
    {
        public static List<Books> BooksList = new List<Books>();
        public bool AddNewBook(Books book)
        {


            var book2 = BooksList.Find(book1 => book1.BookTitle == book.BookTitle);
            if (book2 == null)
            {
                book.BookId = BooksList.Count == 0 ? 500 : BooksList.Max(x => x.BookId = x.BookId + 1);
                BooksList.Add(book2);


                return true;
            }
            return false;
        }
        public List<Books> ViewAllBooks()
        {
            return BooksList;
        }
        public List<Books> ViewBookByAuthor(string AuthorName)
        {
            var booksByAuthor = BooksList.FindAll(book1 => book1.BookAuthor == AuthorName);

            return booksByAuthor;

        }
        public bool RemoveAllBooks()
        {
            if (BooksList.Count > 0)
            {
                BooksList.Clear();
                return true;
            }
            return false;
        }
    }
}
