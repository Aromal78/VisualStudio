﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Assessment_2_Book_Management_System
{

    public class BooksException
    {
        public void ChoiceValidation(bool choice)
        {
            if (!choice)
            {
                throw new BooksExceptionHandler("Invalid Choice !!! You have to enter a number");
            }
        }
        public void ChoiceValidation1(int choice) 
        {
            if ((choice<1)||(choice>4)) 
            {
                throw new BooksExceptionHandler("Invalid Choice !!! You have to enter a number between 1 and 4");
            }
        }

        public void CheckBooks(Books books) 
        {
            if(string.IsNullOrEmpty(books.BookAuthor))
            {
                throw new BooksExceptionHandler("The authors name cannot be null Or empty !!!");
            }
            if (string.IsNullOrEmpty(books.BookTitle))
            {
                throw new BooksExceptionHandler("The authors name cannot be null Or empty !!!");
            }
            if (books.BookPrice<1)
            {
                throw new BooksExceptionHandler("The price of the book  cannot be less than 1 !!!");
            }
            if (books.BookRating < 1 || books.BookRating > 5)
            {
                throw new BooksExceptionHandler("The rating of the book must be between 1 and 5 !!!");
            }
        }
    } 
    internal class BooksExceptionHandler : Exception
    {
        public BooksExceptionHandler(string Message) : base(Message)
        {

        }
    }
}
