﻿namespace Assessment_2_Book_Management_System
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int continueOrNot = 0;
            do
            {
                BooksException booksException = new BooksException();
                BookManagementSystem bookManagementSystem = new BookManagementSystem();

                Console.WriteLine("-----------------Book Management System-----------------------\n");
                Console.WriteLine("1.Add a book");
                Console.WriteLine("2.View all books");
                Console.WriteLine("3.Search by author name");
                Console.WriteLine("4.Remove all books");
                Console.WriteLine("--------------------------------------------------------------");
                Console.WriteLine("Enter a choice (1-4)");
                Console.WriteLine("--------------------------------------------------------------");
                string choiceEntered = Console.ReadLine();
                bool check = int.TryParse(choiceEntered, out int choice);
                try
                {


                    booksException.ChoiceValidation(check);
                    booksException.ChoiceValidation1(choice);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                switch (choice)
                {
                    case 1:
                        {
                            Books books = new Books();
                            Console.WriteLine("Enter the title of the book : ");
                            books.BookTitle = Console.ReadLine();
                            Console.WriteLine("Enter the name of the author of the book : ");
                            books.BookAuthor = Console.ReadLine();
                            Console.WriteLine("Enter the price of the book : ");
                            books.BookPrice = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("Enter the rating of the book (1-5) : ");
                            books.BookRating = Convert.ToDouble(Console.ReadLine());
                            try
                            {
                                booksException.CheckBooks(books);

                            }
                            catch (BooksExceptionHandler ex) { Console.WriteLine(ex.Message); }

                            if (bookManagementSystem.AddNewBook(books))
                            {
                                Console.WriteLine("Book added sucessfully !!!");
                            }
                            else
                            {
                                Console.WriteLine("The book already exits !!!");
                            }
                            break;


                        }
                    case 2:
                        {
                            var book2 = bookManagementSystem.ViewAllBooks();
                            foreach (var book1 in book2)
                            {
                                Console.WriteLine("Book Id ::  " + book1.BookId + "Book Title :: " + book1.BookTitle + " Book Author :: " + book1.BookAuthor + " Book Price :: " + book1.BookPrice + " Book Rating :: " + book1.BookRating);
                            }
                            if (bookManagementSystem.ViewAllBooks().Count == 0)
                            {
                                Console.WriteLine("there are no books to display");
                            }

                            break;

                        }
                    case 3:
                        {
                            Console.WriteLine("Enter the author's name : ");
                            string AuthorNameToSearch = Console.ReadLine();
                            var booksByAuthorName = bookManagementSystem.ViewBookByAuthor(AuthorNameToSearch);
                            foreach (var book1 in booksByAuthorName)
                            {
                                Console.WriteLine("Book Id ::  " + book1.BookId + "Book Title :: " + book1.BookTitle + " Book Author :: " + book1.BookAuthor + " Book Price :: " + book1.BookPrice + " Book Rating :: " + book1.BookRating);
                            }
                            if (booksByAuthorName.Count == 0)
                            {
                                Console.WriteLine("No books found !!!");
                            }
                            break;
                        }
                    case 4:
                        {
                            if (bookManagementSystem.RemoveAllBooks())
                            {
                                Console.WriteLine("All books have been removed sucessfully !!!");
                            }
                            else
                            {
                                Console.WriteLine("There are no books to display");
                            }
                            break;
                        }

                }
                Console.WriteLine("do you want to contine :: 1.Yes ::2.No");
                Console.WriteLine("--------------------------------------------------------------");
                continueOrNot = Convert.ToInt32(Console.ReadLine());


            } while (continueOrNot == 1);

        }
    }
}

