﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_2_Book_Management_System
{
   public class Books
    {
        public string BookAuthor { get; set; }
        public string BookTitle {  get; set; }
        public int BookId { get; set; }
        public Double BookPrice { get; set; }
        public Double BookRating { get; set; }

    }
}
