﻿using System.Drawing;

namespace Assessment_1_Area_Inheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int flag;
            do
            {

                Console.WriteLine("Enter a choice ( Enter : 1 for rectangle | 2 for square)");
                int choice = Convert.ToInt32(Console.ReadLine());

               
                if (choice == 1)
                {
                    Console.WriteLine("Enter the lenght of the rectangle : ");
                    int rectanglelenght = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the breath of the rectangle : ");
                    int rectanglebreath = Convert.ToInt32(Console.ReadLine());
                    Rectangle rectangle = new Rectangle();
                    
                    Console.WriteLine("the area of the rectangle is " + rectangle.Area(rectanglelenght, rectanglebreath));

                }
                else if (choice == 2)
                {
                    Console.WriteLine("Enter the side lenght of the square : ");
                    int squaresidelength = Convert.ToInt32(Console.ReadLine());
                    Rectangle rectangle = new Square();

                    Console.WriteLine("the area of the square is " + rectangle.Area(squaresidelength,squaresidelength));

                }
                else
                {
                    Console.WriteLine("invalid choice");
                    Console.WriteLine("Do you want to continue : type 1 for yes | 2 for no");
                    flag = Convert.ToInt32(Console.ReadLine());
                    break;
                }
                Console.WriteLine("Do you want to continue : (Enter : 1 for yes | 2 for no)");
               
                flag = Convert.ToInt32(Console.ReadLine());


            } while (flag == 1);
            
        }
    }
}