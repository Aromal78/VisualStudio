﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_1_Area_Inheritance
{
   public class Rectangle
    {


        public virtual int Area(int length,int breath)
        {
            return (length * breath);
           
        }

    }
    public class Square : Rectangle
    {
        public override int Area(int side,int side2)
        {
            Console.WriteLine( "hi" );
            return ( side*side2);

        }
    }
}
