﻿// See https://aka.ms/new-console-template for more information
int i = 5;
Console.WriteLine($"{i} Hello, World!");
class Apple
{
    private int count;
}
