﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_4_Palindrome
{
    internal class CheckPalindrome
    {
        public void CheckIfPalindrome(string string1)
        {
            int back = string1.Length - 1;
            int flag = 0;

            for (int front = 0; front < string1.Length; front++)
            {
                if (string1[front] == string1[back])
                {

                    back--;
                }
                else
                {
                    flag = 1;
                    break;


                }
            }
            if (string1.Length == 0)
            {
                Console.WriteLine("the String is empty");
            }

            else if (flag == 0)
            {
                Console.WriteLine("the String " + string1 + " is a palindrome ");
            }
            else if (flag == 1)
            {
                Console.WriteLine("the String " + string1 + " is not a palindrome ");

            }

        }
    }
}

