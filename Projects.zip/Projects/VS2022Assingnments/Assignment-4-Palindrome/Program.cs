﻿namespace Assignment_4_Palindrome
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a string  :  ");
            string string1 = Console.ReadLine();

            CheckPalindrome palindrome = new CheckPalindrome();
            palindrome.CheckIfPalindrome(string1);



            Console.ReadLine();
        }
    }
}
    
