﻿using Assignment_7_ProductManagementApp;
using System.Threading.Channels;

int Flag=0;
do
{
    
    Console.WriteLine("1.Add product");
    Console.WriteLine("2.view all products");
    Console.WriteLine("3.products with price >1000");
    Console.WriteLine("4.Remove all Products");
    Console.WriteLine("5.Exit");
    Console.WriteLine("Enter your choice : ");
    // Product product = new Product();
  
         int Choice = Convert.ToInt32(Console.ReadLine());
   
    


    ProductMangement productMangement = new ProductMangement();
    switch (Choice)
    {
      case 1:
            {
                Product product = new Product();
                Console.WriteLine("Enter the Product Details");
              //  try
                //{
                    Console.WriteLine("Enter product name");
                    product.ProductName = Console.ReadLine();
                    Console.WriteLine("Enter manufactured by :");
                    product.ManufacturedBy = Console.ReadLine();
                    Console.WriteLine("Enter product description :");
                    product.ProductDescription = Console.ReadLine();
                    Console.WriteLine("Enter product price :");

                    product.Price = Convert.ToInt32(Console.ReadLine());
                // }
                //  catch (Exception ex)
                //{
                //    Console.WriteLine($"Message: {ex.Message}");
                //    Console.WriteLine($"Source: {ex.Source}");
                //    Console.WriteLine($"HelpLink: {ex.HelpLink}");
                //    Console.WriteLine($"StackTrace: {ex.StackTrace}");
                //}
                ProductValidationException productValidationException = new ProductValidationException();
                try
                {
                    productValidationException.Productvalidation(product);
                    productMangement.AddProduct(product);
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    
                }

                break;
            }
        case 2:
            {
                productMangement.ViewAllProducts();
                break;

            }
        case 3:
            {
                productMangement.viewAllProductsWithPriceGreaterThan1000();
                break;

            }
        case 4:
            {
                productMangement.RemoveAllProducts();
                break;
            }
        case 5:
            {
                break;

            }
        default:
            {
                Console.WriteLine("Enter a valid choice");
                break;
            }
    }
    Console.WriteLine("Do you Want to continue : 1-yes 2-no");
    Console.WriteLine("-----------------------------------------------------");
    Flag = Convert.ToInt32(Console.ReadLine());
} while (Flag == 1);
