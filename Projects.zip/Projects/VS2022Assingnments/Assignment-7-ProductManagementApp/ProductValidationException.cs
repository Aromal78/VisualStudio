﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_7_ProductManagementApp
{
    internal class ProductValidationException
    {
        public void Productvalidation(Product product) 
        {
            if (string.IsNullOrEmpty(product.ProductName))
            {
                throw new ProductManagementValidation("The product name cannot be null or empty");
            }
            if (string.IsNullOrEmpty(product.ProductDescription))
            {
                throw new ProductManagementValidation("The product description cannot be null or empty");
            }
            if (string.IsNullOrEmpty(product.ManufacturedBy))
            {
                throw new ProductManagementValidation("The Manufactured by cannot be null or empty");
            }
            if (product.Price < 0)
            {
                throw new ProductManagementValidation("the product price must be greater than 0 ");
            }
        }
      
    }
    public class ProductManagementValidation : Exception
    {
        public ProductManagementValidation(string Message) : base(Message)
        {
        }
    }
}
