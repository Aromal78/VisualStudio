﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_7_ProductManagementApp
{
    internal class ProductMangement
    {
      static  List<Product> ProductList = new List<Product>();

        public void AddProduct(Product product)
        {
            
           


            //var maxId = ProductList.Max(x => x.Id) == 0 ? 1000 : ProductList.Max(x => x.Id) + 1;



            var ProductToCheck = ProductList.Find(product1 => product1.ProductName.ToLower() == product.ProductName);
            if (ProductToCheck == null)
            {
                //ProductList.Add(product);

                //var maxId = ProductList.Max(x => x.Id) == 0 ? 1000 : ProductList.Max(x => x.Id) + 1;
                product.Id = ProductList.Count == 0 ? 1000 : ProductList.Max(p => p.Id);

                
                ProductList.Add(product);
                

                Console.WriteLine("Product Added sucessfully");
                Console.WriteLine("-----------------------------------------------------");
            }


        }

        public void RemoveAllProducts()
        {
            if (ProductList.Count > 0)
            {
                ProductList.Clear();
                Console.WriteLine("All Products are Removed");
            }
            else { Console.WriteLine("there are no more products to remove"); }

            Console.WriteLine("-----------------------------------------------------");
        }
        public void viewAllProductsWithPriceGreaterThan1000()
        {

            Console.WriteLine("Products with price greater than 1000   :  ");
            var GreaterThan100 = ProductList.FindAll(Product => Product.Price > 1000);
            if (GreaterThan100.Count > 0)
            {
                foreach (var i in GreaterThan100)
                {
                    Console.WriteLine(i.ProductName + " " + i.ProductDescription);
                }
            }
            else
            {
                Console.WriteLine("there are no products with prize greater than 1000 to view");

            }
            Console.WriteLine("-----------------------------------------------------");
        }
        public void ViewAllProducts()
        {
            foreach (var product in ProductList)
            {
                Console.WriteLine(product.ProductName + " " + product.ProductDescription);
            }

            if (ProductList.Count == 0)
            {
                Console.WriteLine("there are no products to view");
            }
         Console.WriteLine("-----------------------------------------------------");

        }
    }
}
