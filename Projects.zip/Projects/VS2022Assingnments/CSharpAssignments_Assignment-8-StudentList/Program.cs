﻿namespace CSharpAssignments_Assignment_8_StudentList
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StudentValidationException studentValidationException = new StudentValidationException();
            int flag;
            do
            {
                int choice;
                Console.WriteLine("1.Add new student");
                Console.WriteLine("2.View all students");
                Console.WriteLine("3. Students with marks greater than 60");
                Console.WriteLine("4.Remove all students");
                Console.WriteLine("------------------------------------------------------");
                Console.WriteLine("Enter your Choice :-  ");
                Console.WriteLine("------------------------------------------------------");
                string temp=Console.ReadLine();
                bool ch = int.TryParse(temp, out choice);
                if (!ch)
                {
                    Console.WriteLine("Invalid Input");
                    Console.WriteLine("------------------------------------------------------");
                    Console.WriteLine("Do you want to continue 1.Yes|| 2.No ");
                    flag = Convert.ToInt32(Console.ReadLine());
                }
                // choice = Convert.ToInt32(Console.ReadLine());
                try
                {
                    studentValidationException.ChoiceValidate(choice);
                }
                catch (Exception ex)
                { Console.WriteLine(ex.Message); }
               
                StudentMangement studentMangement = new StudentMangement();
                Student student = new Student();
                List<Student> studentList = new List<Student>();
                switch (choice)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter student name:");
                            student.Name = Console.ReadLine();
                            Console.WriteLine("Enter student marks");
                            student.Marks = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter student age");
                            student.Age = Convert.ToInt32(Console.ReadLine());
                            try
                            {
                                studentValidationException.StudentValidate(student);
                                studentMangement.AddStudent(student);
                                Console.WriteLine("Student Got Added Sucessfully !!!");
                            }
                            catch(Exception ex)
                            {
                                
                                Console.WriteLine(ex.Message);
                            }
                            //if (studentMangement.AddStudent(student))
                            //{
                            //    Console.WriteLine("Student added sucessfully");
                            //}
                            //else
                            //{
                            //    Console.WriteLine("a student with the same name already exits");
                            //}
                            break;
                        }

                    case 4:
                        {
                            if (studentMangement.RemoveStudent())
                            {
                                Console.WriteLine("Students removed sucessfully");

                            }
                            else
                            {
                                Console.WriteLine("There are no students to be removed from the list");
                            }
                            break;
                        }
                    case 3:
                        {
                            var studentWithMarksGreaterThan60 = studentMangement.StudentWithMarksGreaterThan60();
                            if (studentWithMarksGreaterThan60.Count == 0)
                            {
                                Console.WriteLine("No students have marks greater than 60 in the current list !!!!");
                            }
                            else
                            {
                                foreach (var student1 in studentWithMarksGreaterThan60)
                                {
                                    Console.WriteLine("Student id :: " + student1.Id + "  Student name :: " + student1.Name + " Student Age :: " + student1.Age + " Student Marks :: " + student1.Marks);
                                }
                            }
                            break;

                        }
                    case 2:
                        {
                            Console.WriteLine("Student Details");
                            Console.WriteLine("-----------------------------------------------------");
                            //studentList = studentMangement.PrintAllStudentDetails();
                            studentList = studentMangement.PrintAllStudentDetails();
                            
                            if (studentList.Count == 0)
                            {
                                Console.WriteLine("there are no elements to view in the current list");
                            }
                            else
                            {
                                foreach (var student1 in studentList)
                                {
                                    Console.WriteLine("Student id :: " + student1.Id + "  Student name :: " + student1.Name + " Student Age :: " + student1.Age + " Student Marks :: " + student1.Marks);
                                }
                            }
                            break;
                        }
                        {

                        }

                }
                Console.WriteLine("------------------------------------------------------");
                Console.WriteLine("Do you want to continue 1.Yes|| 2.No ");
                flag = Convert.ToInt32(Console.ReadLine());
            } while (flag == 1);

            }
            }
        }
