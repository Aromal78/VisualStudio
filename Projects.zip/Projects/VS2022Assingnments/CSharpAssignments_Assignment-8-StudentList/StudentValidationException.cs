﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpAssignments_Assignment_8_StudentList
{
    internal class StudentValidationException
    {
        public void ChoiceValidate(int choice)
        {
            if (((choice < 1) || (choice > 5)))
            {

                throw new ValidateException("Invalid Choice !!!!!! " + "\n" +
                    "Please enter a number between 1 and 4");

            }

        }
        public void StudentValidate(Student student)
        {
            if (string.IsNullOrEmpty(student.Name))
            {
                throw new ValidateException("the Student name cant be null or Empty");
            }
            if ((student.Age <= 1) && (student.Age >= 200))
            {
                throw new ValidateException("the Student Age cant be negative");
            }
            if ((student.Marks <= 0) && (student.Marks > 100))
            {
                throw new ValidateException("the Student marks sholud be between 0 and 100");
            }

        }

        public class ValidateException : Exception
        {
            public ValidateException(string message) : base(message) { }
        }
    }
}
