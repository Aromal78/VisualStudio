﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpAssignments_Assignment_8_StudentList
{
    internal class StudentMangement
    {
        public static List<Student> students = new List<Student>();
        public void AddStudent(Student student)
        {

            //   var student1=students.Find(x=>x.Name==student.Name);
            //if(student1 == null) { 
           
            student.Id = students.Count == 0 ? 1000 : students.Max(x => x.Id + 1);
            //foreach (var student1 in students)
            //{
            //    Console.WriteLine("Student id ::  " + student1.Id + "  Student name ::   " + student1.Name + " Student Age ::" + student1.Age + "  Student Marks :: " + student1.Marks);
            //}
            //}

        }
        public bool RemoveStudent() 
        { 
            
            if(students.Count ==0)
            { return false; }
            else
            {
                students.Clear();
                return true;    
            }
            
        }
        

        public List<Student> StudentWithMarksGreaterThan60()
        {
            var studentsWithGreaterMarks = students.FindAll(student1 => student1.Marks > 60);

                return studentsWithGreaterMarks;

        }
          
        public List<Student> PrintAllStudentDetails()
        {
           
            return students;
        }
        }
    }

