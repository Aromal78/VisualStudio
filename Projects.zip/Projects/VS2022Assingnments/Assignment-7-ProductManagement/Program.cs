﻿namespace Assignment_7_ProductManagement
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Flag;
            do
            {
                Console.WriteLine("Enter your choice");
                Console.WriteLine("1.Add product");
                Console.WriteLine("2.view all products");
                Console.WriteLine("3.products with price >1000");
                Console.WriteLine("4.Remove all Products");
                Console.WriteLine("5.Exit");
                Product product = new Product();

                int Choice = Convert.ToInt32(Console.ReadLine());
                switch (Choice)
                {
                    case 1:
                        {
                            product.AddProduct();
                            break;
                        }
                    case 2:
                        {
                            product.ViewAllProducts();
                            break;

                        }
                    case 3:
                        {
                            product.viewAllProductsWithPriceGreaterThan1000();
                            break;

                        }
                    case 4:
                        {
                            product.RemoveAllProducts();
                            break;
                        }
                    case 5:
                        {
                            break;

                        }
                    default:
                        {
                             Flag = 1;
                            break;
                        }
                }
                Console.WriteLine("Do you Want to continue : 1-yes 2-no");
                Flag = Convert.ToInt32(Console.ReadLine());
            } while (Flag == 1);



    }
    }
}