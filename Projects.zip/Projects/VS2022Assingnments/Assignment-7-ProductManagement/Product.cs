﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_7_ProductManagement
{
    internal class Product
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public int Price { get; set; }
        public string ManufacturedBy { get; set; }
        List<Product> ProductList = new List<Product>();

        public void AddProduct()
        {
            Console.WriteLine("Enter the Product Details");

            Console.WriteLine("Enter product name");
            string ProductName1 = Console.ReadLine();
            Console.WriteLine("Enter manufactured by :");
            string ManufacturedBy1 = Console.ReadLine();
            Console.WriteLine("Enter product description");
            string ProductDescription1 = Console.ReadLine();
            Console.WriteLine("Enter product price");

            int Price1 = Convert.ToInt32(Console.ReadLine());


            //var maxId = ProductList.Max(x => x.Id) == 0 ? 1000 : ProductList.Max(x => x.Id) + 1;
            


                var ProductToCheck = ProductList.Find(product => product.ProductName.ToLower() == ProductName1);
                if (ProductToCheck == null)
                {
                //var maxId = ProductList.Max(x => x.Id) == 0 ? 1000 : ProductList.Max(x => x.Id) + 1;
                ProductList.Add(new Product
                    {
                        //Id = maxId,
                        ProductName = ProductName1,
                        ProductDescription = ProductDescription1,
                        Price = Price1,
                        ManufacturedBy = ManufacturedBy1
                    });


            }
   

        }
    
        public void RemoveAllProducts()
        {
            if (ProductList.Count > 0)
            {
                ProductList.Clear();
                Console.WriteLine("All Products are Removed");
            }
            else { Console.WriteLine("there are no more products to remove"); }
            

        }
        public void viewAllProductsWithPriceGreaterThan1000()
        {

            Console.WriteLine("Products with price greater than 1000");
        var GreaterThan100=ProductList.FindAll(Product => Product.Price > 1000);
            if (GreaterThan100.Count > 0)
            {
                foreach (var i in GreaterThan100)
                {
                    Console.WriteLine(i.ProductName + " " + i.ProductDescription);
                }
            }
            else {
                Console.WriteLine("there are no products with prize greater than 1000 to view");

            }
           
        }
        public void ViewAllProducts()
        {
             foreach (var product in ProductList)
                {
                    Console.WriteLine(product.ProductName + " " + product.ProductDescription);
                }
            
            if(ProductList.Count==0)
            {
                Console.WriteLine("there are no products to view");
            }

        }

    }

}


