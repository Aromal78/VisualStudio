﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_9_MobileManagement
{
    internal class MobileValidationException
    {
        public void ChoiceValidate(int choice)
        {
            if (((choice < 1) || (choice > 7)))
            {
                //Console.WriteLine("choice accepted");
                throw new ValidateException("Invalid Choice !!!!!! " + "\n" +
                    "Please enter a number between 1 and 6");

            }
        }
       
        public void validateMobile(Mobile mobile)
        {
            if (string.IsNullOrEmpty(mobile.Name))
            {
                throw new ValidateException("mobile name can't be null or Empty");
            }
            if (string.IsNullOrEmpty(mobile.ManufacturedBy))
            {
                throw new ValidateException("mobile manufacturer name can't be null or Empty");
            }
            if (string.IsNullOrEmpty(mobile.Description))
            {
                throw new ValidateException("mobile description can't be null or Empty");
            }
            if (mobile.Price <= 0)
            {
                throw new ValidateException("price of an mobile cannot be less than 0 ");
            }
        }
        public void ValidateMobilePrice(bool ch) 
        {
            if (!ch)
            {
                throw new ValidateException("Please enter a valid price");
            }
        }

    }
        public class ValidateException : Exception
        {
            public ValidateException(string message) : base(message) { }
        }
    
}
