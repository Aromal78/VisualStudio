﻿using System.Xml.Serialization;

namespace Assignment_9_MobileManagement
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int choice;
            MobileValidationException mobileValidationException1 = new MobileValidationException();
            do
            {
                Console.WriteLine("------------------------------------------------------");
                Console.WriteLine("Welcome to JoMart !!! ");
                Console.WriteLine("------------------------------------------------------\n");

                Console.WriteLine("1.Add new mobile ");
                Console.WriteLine("2. View all mobiles available in the store");
                Console.WriteLine("3. Search mobiles whose price is less than the max price of mobiles");
                Console.WriteLine("4.Search all mobiles by Manufacturer");
                Console.WriteLine("5. View all mobiles whose price is greater than minimum mobile price and less than maximum mobile price");
               Console.WriteLine("6. Remove mobiles whose price is greater than minimum mobile price and less than maximum mobile price.");
                Console.WriteLine("7.Exit\n");
                Console.WriteLine("------------------------------------------------------");
                Console.WriteLine("Enter your Choice :-  ");
                Console.WriteLine("------------------------------------------------------");
                string temp = Console.ReadLine();
                bool ch = int.TryParse(temp, out choice);
                try
                {
                    
                    mobileValidationException1.ChoiceValidate(choice);
                }
                catch (Exception ex)
                { Console.WriteLine(ex.Message); }                
                Mobile mobile = new Mobile();
                MobileManagement mobileManagement = new MobileManagement();
                List<Mobile> mobileList = new List<Mobile>();
                switch (choice)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter the mobile name :: ");
                            mobile.Name = Console.ReadLine();
                            Console.WriteLine("Enter the mobile description :: ");
                            mobile.Description = Console.ReadLine();
                            Console.WriteLine("Enter the mobile manufactured by :: ");
                            mobile.ManufacturedBy = Console.ReadLine();
                            Console.WriteLine("Enter the mobile price :: ");
                            string temp1 = Console.ReadLine();
                            bool ch1 = int.TryParse(temp, out int price);
                            try
                            {

                                mobileValidationException1.ValidateMobilePrice(ch1);
                                mobileManagement.AddMobile(mobile);
                            }
                            catch (Exception ex)
                            { Console.WriteLine(ex.Message); }
                            try
                            {
                                mobileValidationException1.validateMobile(mobile);
                                bool isAdded = mobileManagement.AddMobile(mobile);
                                if (isAdded)
                                {
                                    Console.WriteLine("--------------------------------------------------------");
                                    Console.WriteLine("Mobile added sucessfully");
                                }
                                else
                                {
                                    Console.WriteLine("Mobile already exsists in our records");
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                           
                            
                            break;
                        }
                    case 2:
                        {
                            mobileList = mobileManagement.ViewAllMobile();
                            if (mobileList.Count == 0)
                            {
                                Console.WriteLine("there are no records to view !!!");
                            }
                            else
                            {
                                Console.WriteLine("List of mobiles :");
                                foreach (var mobiles in mobileList)
                                {
                                    Console.WriteLine("mobile Id ::"+mobiles.Id+ "  mobile name ::" + mobiles.Name+ "mobile description ::" + mobiles.Description + "  mobile manufactured by ::" + mobiles.ManufacturedBy);
                                }
                            }
                            break;
                        }
                    case 3:
                        {
                            var mobilesWithPriceLessThanMaxPrice = mobileManagement.MobilesWithPriceLessThanMaxPrice();
                            if (mobilesWithPriceLessThanMaxPrice.Count == 0)
                            {
                                Console.WriteLine("there are no records to view");
                            }
                            else
                            {
                                Console.WriteLine("list of mobiles With Price Less Than Max Price");
                                foreach (var mobiles in mobilesWithPriceLessThanMaxPrice)
                                {
                                    Console.WriteLine("mobile Id ::" + mobiles.Id + "  mobile name ::" + mobiles.Name + "mobile description ::" + mobiles.Description + "  mobile manufactured by ::" + mobiles.ManufacturedBy);
                                }

                            }
                            break;

                        }
                    case 4:
                        {
                            Console.WriteLine("Enter manufacturer name");
                            string manufacturerName = Console.ReadLine();
                            var MobilesByAManufacturer = mobileManagement.MobilesByAManufacturer(manufacturerName);
                            if(MobilesByAManufacturer.Count == 0)
                            {
                                Console.WriteLine("there are no recrods to view");
                            }
                            else 
                            {
                                foreach (var mobiles in MobilesByAManufacturer)
                                {
                                    Console.WriteLine(mobiles.Id+"  "+mobile.Name);
                                }
                            }
                            break;
                        }
                    case 5:
                        {
                            var mobileListName = mobileManagement.ViewAllMobile();
                            if(mobileListName.Count == 0)
                            {
                                Console.WriteLine("There are no mobiles to display\n");
                            }
                            else
                            {
                                var mobilesWithPriceInBetween = mobileManagement.MobilesWithPriceInBetween();
                                if (mobilesWithPriceInBetween.Count == 0)
                                {
                                    Console.WriteLine("there are no records to view !!!");
                                }
                                else
                                {
                                    Console.WriteLine("List of mobiles :");
                                    foreach (var mobiles in mobilesWithPriceInBetween)
                                    {
                                        Console.WriteLine(mobile.Id + "  " + mobiles.Name);
                                    }
                                }
                            }
                            
                            break;
                        }
                    case 6:
                        {
                            if (mobileManagement.RemoveMobilesWithPriceInBetween())
                            {
                                Console.WriteLine("Sucessfully removed the marks in between");
                            }
                            else
                            {
                                Console.WriteLine("Please enter more records before trying to perform this action");

                            }
                            break;
                        }
                           case 7:
                        { 
                                Console.WriteLine("Exiting the file !!! ");
                        break;
                            }



                }


            } while (choice>=1&&choice<=6);
        }
    }
}