﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_9_MobileManagement
{
    internal class MobileManagement
    {
        public static List<Mobile>mobileList=new List<Mobile>();
        public bool AddMobile(Mobile mobile)
        {
            var checkName=mobileList.Find(x=>x.Name.ToLower()==mobile.Name.ToLower());
            if (checkName==null)
            {
                mobile.Id = mobileList.Count == 0 ? 3000 : mobileList.Max(x => x.Id) + 1;
               
                mobileList.Add(mobile);
                return true;
            }
            return false;
           
        }
        public List<Mobile> ViewAllMobile() 
        {

            return mobileList;
            
        }

        public List<Mobile> MobilesWithPriceLessThanMaxPrice()
        {
            var mobilesWithPriceLessThanMaxPrice = mobileList.FindAll(x => x.Price < mobileList.Max(x => x.Price));
            return mobilesWithPriceLessThanMaxPrice;
         
        }
        public List<Mobile> MobilesByAManufacturer(string manufacturerName)
        {
            var mobilesByAManufacturer=mobileList.FindAll(x=>x.ManufacturedBy.ToLower()==manufacturerName.ToLower());
            return mobilesByAManufacturer;
        }
        public List<Mobile> MobilesWithPriceInBetween()
        {
            //if (mobileList.Count == 0)
            //{

            //    try
            //    {
            //        MobileValidationException mobileValidationException = new MobileValidationException();
            //        mobileValidationException.EmptyList();
            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }
            //}

             var maxPrice = mobileList.Max(x => x.Price);
               var minPrice = mobileList.Min(x => x.Price);
            

           

            //var mobilesWithPriceInBetween =mobileList.FindAll(x=>x.Price > minPrice).Where (x => x.Price < maxPrice);
            var mobilesWithPriceInBetween = mobileList.FindAll(x => x.Price > minPrice&&x.Price < maxPrice);
            return mobilesWithPriceInBetween;
        }
        public bool RemoveMobilesWithPriceInBetween()
        {

            var maxPrice = mobileList.Max(x => x.Price);
            var minPrice = mobileList.Min(x => x.Price);

            if (mobileList.Count > 2)
            {

                mobileList.RemoveAll(x => x.Price > minPrice && x.Price < maxPrice);
                return true;
            }
            return false;
            
            
        }
    }
}
