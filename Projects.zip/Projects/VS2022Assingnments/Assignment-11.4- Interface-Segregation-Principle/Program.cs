﻿namespace Assignment_11._4__Interface_Segregation_Principle
{
    using System;

    // Print-related interfaces
    public interface IPrinter
    {
        void Print();
    }

    public interface IScanner
    {
        void Scan();
    }

    public interface IFaxMachine
    {
        void Fax();
    }

    // Printer class implementing IPrinter
    public class Printer : IPrinter
    {
        public void Print()
        {
            Console.WriteLine("Printing...");
        }
    }

    // Photocopier class implementing IPrinter and IScanner
    public class Photocopier : IPrinter, IScanner
    {
        public void Print()
        {
            Console.WriteLine("Printing...");
        }

        public void Scan()
        {
            Console.WriteLine("Scanning...");
        }
    }

    // FaxMachine class implementing IFaxMachine
    public class FaxMachine : IFaxMachine
    {
        public void Fax()
        {
            Console.WriteLine("Faxing...");
        }
    }

    // Client class
    public class Client
    {
        private IPrinter printer;
        private IScanner scanner;

        public Client(IPrinter printer, IScanner scanner)
        {
            this.printer = printer;
            this.scanner = scanner;
        }

        public void PrintDocument()
        {
            printer.Print();
        }

        public void ScanDocument()
        {
            scanner.Scan();
        }
    }

    public class Program
    {
        public static void Main()
        {
            // Create instances of Printer and Photocopier
            var printer = new Printer();
            var photocopier = new Photocopier();

            // Create a Client instance with Printer
            var clientWithPrinter = new Client(printer, photocopier);
            clientWithPrinter.PrintDocument();

            // Create a Client instance with Photocopier
            var clientWithPhotocopier = new Client(photocopier, photocopier);
            clientWithPhotocopier.PrintDocument();
            clientWithPhotocopier.ScanDocument();
        }
    }

}