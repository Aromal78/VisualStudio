﻿namespace Assignment_11._5_Dependency_Inversion_Principle
{
    using System;

    // Abstraction for the notification channel
    public interface INotificationChannel
    {
        void SendNotification(string message);
    }

    // Email notification channel
    public class EmailChannel : INotificationChannel
    {
        public void SendNotification(string message)
        {
            Console.WriteLine("Sending email notification: " + message);
        }
    }

    // SMS notification channel
    public class SmsChannel : INotificationChannel
    {
        public void SendNotification(string message)
        {
            Console.WriteLine("Sending SMS notification: " + message);
        }
    }

    // NotificationSender class depends on the abstraction
    public class NotificationSender
    {
        private INotificationChannel channel;

        public NotificationSender(INotificationChannel channel)
        {
            this.channel = channel;
        }

        public void SendNotification(string message)
        {
            channel.SendNotification(message);
        }
    }

    public class Program
    {
        public static void Main()
        {
            // Create instances of EmailChannel and SmsChannel
            var emailChannel = new EmailChannel();
            var smsChannel = new SmsChannel();

            // Create a NotificationSender with EmailChannel
            var emailNotificationSender = new NotificationSender(emailChannel);
            emailNotificationSender.SendNotification("Hello via email!");

            // Create a NotificationSender with SmsChannel
            var smsNotificationSender = new NotificationSender(smsChannel);
            smsNotificationSender.SendNotification("Hello via SMS !");
        }
    }

}