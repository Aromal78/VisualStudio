﻿using System.Drawing;

namespace Assignment_11._2_Open_Closed_Principle
{
    public abstract class Shape
    {
        public abstract double CalculateArea();
    }

    // Circle class
    public class Circle : Shape
    {
        public double Radius { get; set; }

        public override double CalculateArea()
        {
            return Math.PI * Math.Pow(Radius, 2);
        }
    }
    public class Rectangle : Shape
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public override double CalculateArea()
        {
            return Width * Height;
        }
    }

    // AreaCalculator class
    public class AreaCalculator
    {
        public double CalculateTotalArea(Shape[] shapes)
        {
            double totalArea = 0;
            foreach (var shape in shapes)
            {
                totalArea += shape.CalculateArea();
            }
            return totalArea;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            // Create an array of shapes
            Shape[] shapes = {
            new Circle { Radius = 5 },
            new Rectangle { Width = 4, Height = 6 }
        };

            // Calculate the total area
            var calculator = new AreaCalculator();
            double totalArea = calculator.CalculateTotalArea(shapes);
            Console.WriteLine("Total Area: " + totalArea);
        }
    }
}