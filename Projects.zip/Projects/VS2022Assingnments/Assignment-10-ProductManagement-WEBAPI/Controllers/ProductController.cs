﻿using Assignment_10_ProductManagement_WEBAPI.Models;
using Assignment_10_ProductManagement_WEBAPI.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assignment_10_ProductManagement_WEBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        IProductService productService;


        public ProductController(IProductService productService)
        {
            this.productService = productService;
        }

        [HttpGet]
        public IActionResult GetAllProduct()
        {
            var products = productService.GetAllProducts();
            if (products.Count() == 0)
            {
                return NotFound("there are no products to display");
            }
            else
            {
                return Ok(products);
            }
        }
        [HttpPost]
        public IActionResult AddProduct([FromBody] Products products)
        {

            return Ok(productService.Add_Products(products));


        }
        [HttpDelete("{Id}")]
        public IActionResult DeleteProduct(int Id)
        {
           if(productService.Delete_Product(Id))
            {
                return Ok("Product Deleted Sucessfully !!!");
            }
           return NotFound(" Product not found !!!");
        }
        [HttpPut("{Id}")]
        public IActionResult UpdateProduct([FromBody]Products products,int Id)
        {
            if(productService.Update_Products(products, Id))
            {
                return Ok("Updated Sucessfully");
            }
            return NotFound("Product Not Found");
        }
        [HttpGet("{Price}")]
        
        public IActionResult GetProductByPrice(int Price) 
        { 
            if(productService.Produts_With_Greater_Price(Price).Count() == 0)
            {
                return NotFound("there are no records with greater Price");
            }
            return Ok(productService.Produts_With_Greater_Price(Price));
        }

    }

}
