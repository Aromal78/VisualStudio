﻿using Assignment_10_ProductManagement_WEBAPI.Models;

namespace Assignment_10_ProductManagement_WEBAPI.Services
{
    public interface IProductService
    {
        public IReadOnlyList<Products> GetAllProducts();
        public Products Add_Products(Products product);
        public bool Update_Products(Products products, int id);
        public bool Delete_Product(int id);

        public List<Products> Produts_With_Greater_Price(int Amount);
    }
}
