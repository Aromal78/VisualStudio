﻿
using Assignment_10_ProductManagement_WEBAPI.Models;

namespace Assignment_10_ProductManagement_WEBAPI.Services
   
{
    public class ProductServices : IProductService
    {
        public  List<Products> products = new List<Products>();
        public Products Add_Products(Products product)
        {
            product.Id = products.Count() == 0? 1: products.Max(x=>x.Id)+1;
            products.Add(product);
            return product;
        }
        public IReadOnlyList<Products> GetAllProducts()
        {
            return products;
        }
        public bool Delete_Product(int id)
        {
            var deleteproduct=products.Find(Temp_product=> Temp_product.Id == id);
            if (deleteproduct != null)
            {
                products.Remove(deleteproduct);
                return true;
            }
            else { return false; }
        }
        public bool Update_Products(Products product,int id) 
        {
            var updateProduct = products.Find(Temp_product => Temp_product.Id == id);
            if (updateProduct != null)
            {
                updateProduct.Name = product.Name;
                updateProduct.Description = product.Description;
                updateProduct.Amount = product.Amount;
                return true;
            }
            return false;
        }
        public List<Products> Produts_With_Greater_Price(int Amount)
        {
            var ProductsWithGreaterAmount=products.FindAll(x=> x.Amount >Amount);
            
            
            return ProductsWithGreaterAmount;

            
        }
    }
}
