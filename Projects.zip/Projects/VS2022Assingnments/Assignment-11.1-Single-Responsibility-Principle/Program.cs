﻿namespace Assignment_11._1_Single_Responsibility_Principle
{
    public class Customer
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
    }
    public class CustomerRepository
    {
 
        public void SaveToDatabase(Customer customer)
        {
            // Simulating saving the customer to the database
            Console.WriteLine("Saving customer to the database: " + customer.Name);
        }

        public Customer RetrieveFromDatabase(string customerId)
        {
            // Simulating retrieving a customer from the database
            Console.WriteLine("Retrieving customer from the database: " + customerId);
            return new Customer { Name = "John Doe", Email = "johndoe@example.com", PhoneNumber = "1234567890" };
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        { 
        // Creating a customer
        var customer = new Customer { Name = "Alice Smith", Email = "alice@example.com", PhoneNumber = "9876543210" };

        // Saving the customer to the database
        var repository = new CustomerRepository();
        repository.SaveToDatabase(customer);

        // Retrieving a customer from the database
        var retrievedCustomer = repository.RetrieveFromDatabase("123");
        Console.WriteLine("Retrieved customer: " + retrievedCustomer.Name);
    }
}
}