﻿namespace Assignment_5_SumOfNaturalNumbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Flag=1;
            do
            {
                int InputNumber;
                Console.WriteLine("Enter the natural number ");
                InputNumber = Convert.ToInt32(Console.ReadLine());
                if (InputNumber < 1)
                {
                    Console.WriteLine("enter a number grater than 1");
                    Console.WriteLine("Do you want to continue(1.yes|2.no)");
                    Flag = Convert.ToInt32(Console.ReadLine());
                    break;
                }
                Sum sum = new Sum();
                sum.SumOfNNaturalNumbers(InputNumber);
                Console.WriteLine("Do you want to continue(1.yes|2.no)");
                Flag = Convert.ToInt32(Console.ReadLine());
            }
            while (Flag==1);
        }
    }
}