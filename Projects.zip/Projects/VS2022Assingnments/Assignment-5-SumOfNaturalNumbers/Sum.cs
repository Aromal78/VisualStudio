﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_5_SumOfNaturalNumbers
{
    internal class Sum
    {
        public int Sum1=0;
        public void SumOfNNaturalNumbers(int InputNumber)
        {
            for (int i = 1; i<=InputNumber; i++)
            {
                Sum1 = Sum1 + i;
            }
            Console.WriteLine("the sum of the frist "+InputNumber+" natural numbers is "+ Sum1);
        }
    }
}
