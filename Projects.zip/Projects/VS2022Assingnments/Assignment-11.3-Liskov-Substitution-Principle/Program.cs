﻿namespace Assignment_11._3_Liskov_Substitution_Principle
{
    public abstract class Vehicle
    {
        public void Start()
        {
            Console.WriteLine("Vehicle starting...");
        }

        public void Stop()
        {
            Console.WriteLine("Vehicle stopping...");
        }

        public abstract void Accelerate();
    }

    // Car class
    public class Car : Vehicle
    {
        public override void Accelerate()
        {
            Console.WriteLine("Car accelerating...");
        }
    }

    // Motorcycle class
    public class Motorcycle : Vehicle
    {
        public override void Accelerate()
        {
            Console.WriteLine("Motorcycle accelerating...");
        }
    }

    // VehicleController class
    public class VehicleController
    {
        public void ControlVehicle(Vehicle vehicle)
        {
            vehicle.Start();
            vehicle.Accelerate();
            vehicle.Stop();
        }
    }

    public class Program
    {
        public static void Main()
        {
            // Create instances of Car and Motorcycle
            var car = new Car();
            var motorcycle = new Motorcycle();

            // Create a VehicleController instance
            var vehicleController = new VehicleController();

            // Control the car and motorcycle using the VehicleController
            vehicleController.ControlVehicle(car);
            Console.WriteLine("----------------");
            vehicleController.ControlVehicle(motorcycle);
        }
    }
}