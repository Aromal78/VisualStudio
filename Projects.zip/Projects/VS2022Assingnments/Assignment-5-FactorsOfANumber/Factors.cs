﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_5_FactorsOfANumber
{
    internal class Factors
    {

        public void FactorsAOfNumbers(int InputNumber)
        {
            Console.WriteLine("The factors of " + InputNumber + "  are  :");
            for (int i = 1; i <= InputNumber; i++)
            {
                if(InputNumber%i == 0)
                Console.WriteLine(i);
            }

        }
    }
}
