﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CircleLibrary1
{
    public class Circle
    {
        int _radius;
        static float pi;

        static Circle()
        {
            pi = 3.14f;
        }
        public Circle(int radius)
        {
            _radius = radius;
        }
        public float CaculateArea()
        {
            return pi * this._radius * this._radius;
        }

    }
}
