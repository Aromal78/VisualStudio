﻿using System.Security.Cryptography.X509Certificates;

namespace ExceptionHandlingTrail
{
    internal class Program
    {
        static void Main(string[] args)
        {
         int a=23;
         int b=0;
            try
            {
                int c = a / b;
            }
            catch(DivideByZeroException e)
            {
                Console.WriteLine(e);

            }
            ExceptionHandler2 exceptionHandler = new ExceptionHandler2();
            try
            {
                int D = 0;
                exceptionHandler.GreaterThan1(D);
            }
            catch(ExceptionHandler1 ex)
            {
                Console.WriteLine(ex.Message);
            }
         }
    }
}