﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingTrail
{
    internal class ExceptionHandler1 : Exception
    {
        public ExceptionHandler1(string Message) : base(Message) { }
          
    }
    public class ExceptionHandler2
    {
        public void GreaterThan1(int number)
        {
            if(number <= 0)
            {
                throw new ExceptionHandler1("the value od D must be greater than 0");
            }
        }
    }
}
