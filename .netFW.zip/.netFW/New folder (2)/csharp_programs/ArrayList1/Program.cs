﻿namespace ArrayList1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Students students = new Students(); 
           List<Students> students1 = new List<Students>();
            var students2 = students1.FindAll(students3=>students3.Name ==students.Name);
            var student4 = students1.Find(student3 => student3.Marks > 90);
            var students4=students1.ToList();
            foreach(var student in students4)
            {

                Console.WriteLine(student.Name);
            }
            
        }
    }
}