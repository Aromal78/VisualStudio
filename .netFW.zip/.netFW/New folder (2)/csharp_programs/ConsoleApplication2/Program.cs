﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            ////   int maxValue = int.MaxValue;
            ////   Console.WriteLine("maxValue of integer is  " + maxValue+" hello");
            ////   Console.ReadLine();
            ////   float f=float.MaxValue;
            ////    Console.WriteLine("maxValue of float is " + f);
            ////    Console.ReadLine();
            ////   bool b = true;

            //bool b = true;
            //string f;
            //while (b == true)
            //{
            //    Console.Write("Write Your Name: ");
            //    string c = Console.ReadLine();
            //    Console.Write("Enter your age: ");
            //    int Age = Convert.ToInt32(Console.ReadLine());




            //    if (Age > 18)
            //    {
            //        Console.WriteLine("hello " + c + ", you are a major");
            //    }
            //    else
            //    {
            //        Console.WriteLine("hello " + c + ", you are a minor");

            //    }
            //    Console.WriteLine("Do you want to continue(true/false)");
            //    f = Console.ReadLine();
            //    if (f == "false")
            //    {
            //        break;
            //    }
            //    //   {
            //    //       b = true;

            //    //   }
            //    //   else
            //    //   {
            //    //        b = false;
            //    //   }
            //    float number1 = 123F;
            //    int number2 = (int)number1;
            //    Console.WriteLine(number2);
            //    int result;
            //    int a = int.Parse("abcd");
            //    bool isCovertible = int.TryParse("abcd", out result);

            //    int n;


            //    Console.Write("Enter the total numbers: ");
            //    n = Convert.ToInt32(Console.ReadLine());
            //    int[] x = new int[n];


            //    int f = 1, i = 0;
            //    while (f == 1)
            //    {
            //        Console.Write("Enter any numbers: ");
            //        x[i] = Convert.ToInt32(Console.ReadLine());
            //        if (x[i] % 2 == 0)
            //        {
            //            Console.Write("the number " + x[i] + " is even \n");
            //        }
            //        else
            //        {
            //            Console.Write("the number " + x[i] + " is odd \n");

            //        }
            //        Console.Write("do you want to continue(1/0)");
            //        f = Convert.ToInt32(Console.ReadLine());
            //        if (f == 0)
            //        {
            //            break;

            //        }

            //    }


            //    int n, sum = 0;


            //    Console.Write("Enter the total numbers: ");
            //    n = Convert.ToInt32(Console.ReadLine());
            //    int[] x = new int[n];


            //    for (int i = 0; i < n; i++)
            //    {
            //        Console.Write("Enter the " + (i + 1) + "number");
            //        x[i] = Convert.ToInt32(Console.ReadLine());

            //    }
            //    for (int i = 0; i < n; i++)
            //    {
            //        sum = sum + x[i];
            //    }
            //    Console.Write("the sum of the numbers is" + sum);


            //}

        }
    }

}

