﻿namespace ExceptionHandlingTrail2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int flag = 1;
            do
            {
                int a;
                Console.WriteLine("enter a number:(1-5)");
                string b = Console.ReadLine();
                bool b2 = int.TryParse(b, out a);
                

                try
                {
                    ExceptionHandler handler = new ExceptionHandler();
                    handler.IntegerOrNot(b2);
                    handler.CheckNumber(a);
                }
                catch (Exception ex)
                { Console.WriteLine(ex.Message); }


            } while (flag == 1);
        }
    }
}