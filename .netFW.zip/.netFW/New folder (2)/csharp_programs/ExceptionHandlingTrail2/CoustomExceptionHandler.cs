﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingTrail2
{
    public class ExceptionHandler
    {
        public void CheckNumber(int num)
        {
            if (num < 0 || num > 5)
            {
                throw new CoustomExceptionHandler("the number must be between 1 and 5");
            }
        }
        public void IntegerOrNot(bool num)
        {
            if (!num)
            {
                throw new CoustomExceptionHandler("Invalid Input !!! Please Enter a Number");
            }
        }
    }
    internal class CoustomExceptionHandler :Exception
    {
        public CoustomExceptionHandler(string message):base(message) { }
    }
}
