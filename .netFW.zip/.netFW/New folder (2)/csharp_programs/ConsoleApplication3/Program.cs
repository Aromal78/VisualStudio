﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CircleLibrary1;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            //coustomer c1 = new coustomer("Arun");
            //coustomer c2 = new coustomer("Arun", "MOhan");
            Circle circle1 = new Circle(5);
            Circle circle2 = new Circle(1);
           float Area = circle1.CaculateArea();
           float Area1 = circle2.CaculateArea();
           Console.Write(Area+"\n");
           Console.Write(Area1);
            Console.ReadLine();

            //c2.DisplayCustomerName();
            //c1.DisplayCustomerName();
        }
    }
    
    
}
