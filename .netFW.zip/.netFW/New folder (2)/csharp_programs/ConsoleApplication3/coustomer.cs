﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    class coustomer
    {
        string fristName = "James";


        public coustomer(string name)
        {
            fristName = name;
        }

        public coustomer(string fristName, string lastname)
        {

        }

        public void DisplayCustomerName()
        {
            Console.WriteLine("Name is {0}", fristName);
            Console.ReadLine();
        }
     
           

    }

    
}
