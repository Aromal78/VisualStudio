﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Runner
    {
        public static void Main(string[] args)
        {
            Hello.Display();
            Hello hello=new Hello();
            hello.GetInformation();
            Console.ReadLine();

        }
    }
}
