﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public  class Hello
    {
        public static void Display()
        {
            Console.WriteLine("inside Display Mthothd!");
        }
        public void GetInformation()
        {
            Console.WriteLine("Inside GetInformation Method!");
        }
        
    }
}
